package day10_OOP;

public class Quiz02_Main {
	public static void main(String[] args) {
		Quiz02_OddEven oddEven = new Quiz02_OddEven();
		oddEven.inputNum();
	}
}
