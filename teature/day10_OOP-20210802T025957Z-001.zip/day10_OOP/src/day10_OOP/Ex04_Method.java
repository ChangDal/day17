package day10_OOP;

public class Ex04_Method {
	public static void main(String[] args) {
		Member04 mem = new Member04();
		mem.reverse();
	}
}
