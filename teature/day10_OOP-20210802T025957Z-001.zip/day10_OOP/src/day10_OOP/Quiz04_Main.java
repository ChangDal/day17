package day10_OOP;

public class Quiz04_Main {
	public static void main(String[] args) {
		Quiz04_�Ҽ� quiz04 = new Quiz04_�Ҽ�();
		quiz04.input();
	}
}
