package day02_����_������;

import java.io.IOException;

public class Ex04 {
	public static void main(String[] args) throws IOException {
		int val, val02;
		System.out.println("val �Է� : ");
		val = System.in.read();
		
		System.in.read();
		System.in.read();
		
		System.out.println("val02 �Է� : ");
		val02 = System.in.read();
		
		System.out.println("val : "+val);
		System.out.println("val02 : "+val02);
	}
}





