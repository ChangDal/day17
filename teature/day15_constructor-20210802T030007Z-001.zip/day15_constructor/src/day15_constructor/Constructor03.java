package day15_constructor;

public class Constructor03 {
	private int age;
	public static int test=1234;
	public Constructor03(int age) {
		this.age = age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getAge() { return age; }
}
