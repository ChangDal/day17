package day15_constructor;

public class Constructor02 {
	public Constructor02(int num) { }
	public Constructor02() { }
	public Constructor02(String s) { }
}
