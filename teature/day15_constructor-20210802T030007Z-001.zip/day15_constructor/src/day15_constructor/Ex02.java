package day15_constructor;

import java.util.Scanner;

public class Ex02 {
	public static void main(String[] args) {
		Constructor02 con = new Constructor02();
		Constructor02 con1 = new Constructor02(123);
		Constructor02 con2 = new Constructor02("123");
	}
}
