package test_java;

//https://www.naver.com/
// com.naver.������Ʈ�̸�.
import java.util.Date;

import com.kg.test.*;
public class TestMain {
	public static void main(String[] args) {
		TestClass tc = new TestClass();
		tc.test();
		Ex03 ex03 = new Ex03();
		ex03.ex03();
		Ex03_1 ex3 = new Ex03_1();
		ex3.ex03();
		day14_class.Ex03 dd = new day14_class.Ex03();
		//dd.test();
	}
}
