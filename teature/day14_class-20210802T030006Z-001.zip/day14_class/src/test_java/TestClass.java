package test_java;

public class TestClass {
	void test() {
		System.out.println("TestClass test �Դϴ�");
	}
}
