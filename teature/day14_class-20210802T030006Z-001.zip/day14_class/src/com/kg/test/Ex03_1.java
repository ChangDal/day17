package com.kg.test;
public class Ex03_1 {
	public void ex03() {
		System.out.println("test Ex03-1 ex03");
	}
}
