package com.kg.test;

public class Ex03 {
	public void ex03() {
		System.out.println("test Ex03 ex03");
	}
}
