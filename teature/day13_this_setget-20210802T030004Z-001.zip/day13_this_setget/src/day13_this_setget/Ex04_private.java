package day13_this_setget;

public class Ex04_private {
	private int kor,eng,math,sum;
	private double avg;
	public int getKor() { return kor; }
	public void setKor(int kor) { this.kor = kor; }
	public int getEng() { return eng; }
	public void setEng(int eng) { this.eng = eng; }
	public int getMath() { return math; }
	public void setMath(int math) { this.math = math; }
	public int getSum() { return sum; }
	public void setSum(int sum) { this.sum = sum; }
	public double getAvg() { return avg; }
	public void setAvg(double avg) { this.avg = avg; }
	
}
