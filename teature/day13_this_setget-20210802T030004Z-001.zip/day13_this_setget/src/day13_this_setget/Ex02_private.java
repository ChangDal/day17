package day13_this_setget;

public class Ex02_private {
	private int num, age;
	public int getNum() {
		return num;
	}
	public void printNum() {
		System.out.println( num );
	}
	public void setNum(int n) {
		num = n;
	}
	public void setAge(int a) {
		age = a;
	}
}




