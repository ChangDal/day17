package day12_ClassVariable;
public class Variable04 {
	private int var=100;
	public void variable(){
		//int var=100;
		System.out.println("var : "+var);
		//return var;
	}
	public void func(){ //int var){
		System.out.println("var : "+var);
	}
}
