package day12_ClassVariable;

public class Variable05 {
	public static int cnt=12345;
	public static void print() {
		System.out.println(cnt);
	}
}
