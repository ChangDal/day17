package day12_ClassVariable;

public class Test {
	public static void main(String[] args) {
		System.out.println("=== up & d ====");
		System.out.println("=== up & d ====");
		System.out.println("=== up & d ====");
		System.out.println("=== up & d ====");
		System.out.println("=== up & d ====");
		System.out.println("=== up & d ====");
	}
}
