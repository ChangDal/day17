package day12_ClassVariable;

public class Ex05_Main {
	public static void main(String[] args) {
		Variable05.cnt = 5555;
		Variable05.print();
	}
}
