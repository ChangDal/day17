package day12_ClassVariable;

public class Variable01 {
	public int saveData(){
		int data = 100;
		//print(data);
		return data;
	}
	public void print(int data) {
		System.out.println("data : "+data);
	}
}
