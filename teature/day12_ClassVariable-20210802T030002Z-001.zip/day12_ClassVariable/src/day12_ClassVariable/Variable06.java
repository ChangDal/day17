package day12_ClassVariable;

public class Variable06 {
	public static final String KOREA = "���ѹα�";
	public final static String PI = "3.14";
	public static String test="test";
}
