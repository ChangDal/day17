package day12_ClassVariable;

public class Ex01 
{
	public static void main(String[] args) 
	{
		int i=0;
		while(i < 1) 
		{
			int result = 100;
			i++;
			System.out.println(result);
		}
		//System.out.println(result);
	}
}










