package day12_ClassVariable;

public class Ex07_Main {
	public static void main(String[] args) {
		Variable07 val = new Variable07();
		val.input();
		val.disply();
	}
}

