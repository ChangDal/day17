package day12_ClassVariable;

public class Ex04_Main {
	public static void main(String[] args) {
		Variable04 va = new Variable04();
		//int var = va.variable();
		//va.func(var);
		va.variable();
		va.func();
		//va.var = 1234;
	}
}






