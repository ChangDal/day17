package day12_ClassVariable;

public class Ex06_Main {
	public static void main(String[] args) {
		System.out.println( Variable06.test );
		System.out.println( Variable06.KOREA );
		System.out.println( Variable06.PI );
		Variable06.test = "ABCD";
		//Variable06.KOREA = "TEST";
	}
}
