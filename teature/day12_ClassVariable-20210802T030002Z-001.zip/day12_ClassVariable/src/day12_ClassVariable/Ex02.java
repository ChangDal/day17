package day12_ClassVariable;

public class Ex02 {
	public static void main(String[] args) {
		Variable01 val = new Variable01();
		int d = val.saveData();
		val.print(d);
	}
}
