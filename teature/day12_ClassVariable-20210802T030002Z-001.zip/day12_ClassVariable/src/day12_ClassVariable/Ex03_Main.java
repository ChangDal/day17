package day12_ClassVariable;

public class Ex03_Main {
	public static void main(String[] args) {
		Variable02 val = new Variable02();
		val.test1(); val.test2();
	}
}
